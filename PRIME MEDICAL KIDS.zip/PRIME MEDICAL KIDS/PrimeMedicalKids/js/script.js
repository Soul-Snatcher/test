document.getElementById('contactForm').addEventListener('submit', function (event) {
    let isValid = true;

    // Get form elements
    const name = document.getElementById('floatingName');
    const email = document.getElementById('floatingEmail');
    const message = document.getElementById('floatingMessage');

    // Name validation
    if (name.value.trim() === '') {
        name.classList.add('is-invalid');
        isValid = false;
    } else {
        name.classList.remove('is-invalid');
        name.classList.add('is-valid');
    }

    // Email validation - Improved regex
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    var emailValue = email.value.trim();
    if (!emailPattern.test(emailValue)) {
        email.classList.add('is-invalid');
        isValid = false;
    }
    else {
        email.classList.remove('is-invalid');
        email.classList.add('is-valid');
    }

    // Message validation
    if (message.value.trim() === '') {
        message.classList.add('is-invalid');
        isValid = false;
    } else {
        message.classList.remove('is-invalid');
        message.classList.add('is-valid');
    }

    if (!isValid) {
        event.preventDefault(); // Prevent form submission if validation fails
    }
});